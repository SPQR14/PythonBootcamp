#include <stdio.h>
#include <time.h>

int main(){
    printf("Examinando en busca de problemas con el equipo\n");
    sleep(1000000000000000);
    printf("No se hallaron problemas en el equipo");
    return 0;
}