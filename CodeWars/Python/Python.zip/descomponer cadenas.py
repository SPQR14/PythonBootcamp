def string_to_array(string):
    return string.split() if string else ['']
