s = "1234567899"
for i in range(0, len(s) - 1):
    if s[i] == '3':
        pass