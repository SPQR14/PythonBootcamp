a = 8
b = 18

if a < b:
    print("False")